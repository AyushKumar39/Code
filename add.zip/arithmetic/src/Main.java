 public class Main
 {
     public static void main(String []args)
     {
         float a=12.5f,b=2.2;
         float r=a%b;
         System.out.println(r);
     }
}