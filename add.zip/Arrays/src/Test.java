public class Test {
    static  int x=10;
    public static void main(String []args){
        Test t=new Test();
       // System.out.println(t.x);
       // System.out.println(Test.x);
        // System.out.println(x);

    }
    public void m1(){
        System.out.println(x);
    }
}
