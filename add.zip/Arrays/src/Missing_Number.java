public class Missing_Number {
    public static int missing_Number(int a[],int n){
     int sum,sum1=0,sum2=0;
     for(int i=0;i<a[i];i++){
         sum1=sum1+a[i];
     }
     for(int i=0;i<=n;i++){
         sum2=sum2+i;
     }
     sum=sum2-sum1;
     return sum;
    }
//    public static void main(String []args){
//        missing_Number(a);
//    }
}
