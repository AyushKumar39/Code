import java.lang.*;
import java.util.*;

class Divisible_by_7
{
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the size of array ");
         int x=sc.nextInt();
         int a[]=new int[x];

         for (int i=0;i<a.length;i++)
         {
             System.out.println("\n enter the value ");
             a[i]= sc.nextInt();

             if (a[i]%7==0)
             {
                 System.out.println("divisible by 7 : " +a[i]);
             }
             else
             {
                 System.out.println("not divisible by 7 : " +a[i]);
             }
         }

    }
}

