 class Line1{
    public int p1;
    public int p2;
    public Line1(int P1, int P2) {
         this.p1=p1;
         this.p2=p2;
    }
//    public Line(int x,int y,int x1,int y1){
//       this.p1 =x+y;
//       this.p2 =x1+y1;
//    }
    public int getP1(){
        return p1;
        }
        public double getP2(){
        return p2;
        }
       public String toString(){
        return "Line :" +"p1" +p1 +"p2" +p2;
       }
}
public class Line{
    public static void main(String []args) {
        Line1 l = new Line1(3,5);
        System.out.println(l.getP1());
    }

}
