 import java.lang.*;
import java.util.*;

class Sum_of_array
{
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the size of array : ");
        int a=sc.nextInt();
        int x[]=new int[a];
       int  sum =0;

        for(int i=0;i<x.length;i++)
        {
            System.out.println("enter the value ");
            x[i] = sc.nextInt();

            sum = sum + x[i];
        }
        System.out.println("sum of value is : " +sum);
    }
}