import java.lang.*;
import java.util.*;

class keyboard
        {
          public static  void main(String arg[])
          {
              Scanner s=new Scanner(System.in);
              double a,b,c;
              System.out.println("enter two number");
              a=s.nextDouble();
              b=s.nextDouble();
              c=a+b;
              System.out.println("sum is "+c);
          }
        }
