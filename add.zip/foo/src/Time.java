  class Test{
    static {
        System.out.println("Block 1");
    }
    static{
        System.out.println("Block 2");
    }
  }
class StaticPractice{
    public static void main(String []args){
        System.out.println("main");
        Test t=new Test();
      }
 }
