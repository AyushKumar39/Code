import java.lang.*;
import java.util.Scanner;

class Reversed_number {
  /*  public static void main(String []args)
    {
        int  number,reverse=0;
        Scanner sc=new Scanner(System.in);
           number=sc.nextInt();

        while(number !=0)
        {
          int remainder =number%10;
          reverse = reverse*10+remainder;
           number = number/10;
        }
          System.out.println("the reverse number of given number is " +reverse);
    }*/

    public static void main(String[] args)
    {
        int n,reverse=0;
        Scanner sc=new Scanner (System.in);
        n=sc.nextInt();

        System.out.println("number " +n);
        while(n>0)
        {
            int lastdigits=n%10;
            reverse=reverse*10+lastdigits;
            n=n/10;
                    System.out.println("reverse number " +reverse);

        }


    }

}
