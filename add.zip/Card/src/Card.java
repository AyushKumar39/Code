 import java.util.*;
public class Card{
private String suits;
private String rank;

public Card(int suits,int rank ){
    if(rank>0 && rank<=13){
        this.rank=rank;
    }else{

    }
}
}