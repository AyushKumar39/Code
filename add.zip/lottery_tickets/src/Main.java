import java.lang.*;
import java.util.*;
 class Lottery_System{
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size of array :");
        int a=sc.nextInt();
        int x[]=new int[a];
    for(int v:x){
        System.out.println("element of the array :"+v);
    }
    }
}