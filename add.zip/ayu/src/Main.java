 public class Main
 {
     public static void main(String []args)
     {
         float a=37;
         long b=4;
          float c=a%b;
         System.out.println(c);
     }
}