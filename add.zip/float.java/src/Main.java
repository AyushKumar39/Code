import java.lang.*;
import java.util.*;

class Keyboard
{
    public static void main(String ard[])
    {
        Scanner s=new Scanner (System.in);
        float a,b,c;
        System.out.println("enter two number");
        a=s.nextFloat();
        b=s.nextFloat();
        c=a-b;
        System.out.println("subtract is " +c);
    }
}
