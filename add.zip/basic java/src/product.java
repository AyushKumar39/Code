import java.util.Scanner;
public class product {
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
                    int a,b;
                     System.out.print("first number : ");
                     a=sc.nextInt();
                    System.out.print("second number : " );
                    b=sc.nextInt();
                    System.out.print("product of a and b : " +a*b);
    }
}
