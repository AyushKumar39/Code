import java.util.Scanner;
public class basic {
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        System.out.print("enter the number ");
        int a=sc.nextInt();
        int b=sc.nextInt();
        int c=sc.nextInt();
        System.out.println(a+b*c);
    }
}
