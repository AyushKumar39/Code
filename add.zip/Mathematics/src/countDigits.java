import java.util.Scanner;

public class countDigits {
   public static void main(String []args){
//        Scanner sc=new Scanner(System.in);
//
//
//    }
//    public static int Digts(int x){
//        int reverse=0;
//        while(x>0){
//            x=x/10;
//            reverse++;
//        }
//        return reverse;

       int x=5;
       System.out.print(~x);

    }

}
