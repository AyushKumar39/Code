//import java.lang.*;
import java.util.*;

class Array_String{
    public static void main(String []args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of String array : ");
        int x= sc.nextInt();
        String y[]=new String[x];

        for(int i=0;i<x;i++) {
           y[i]=sc.next();
        }
        for(int i=0;i<y.length;i++){
            System.out.println("name" + (i+1) +" is : " +y[i]);
        }
    }
}
/*import java.util.*;

 class Arrays {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int size = sc.nextInt();
        String names[] = new String[size];

        //input
        for(int i=0; i<size; i++) {
            names[i] = sc.next();
        }

        //output
        for(int i=0; i<names.length; i++) {
            System.out.println("name " + (i+1) +" is : " + names[i]);
        }

    }
}*/
