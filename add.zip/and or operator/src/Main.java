import java.lang.*;
import java.util.Scanner;

class Operator
{
    public static void main(String []args)
    {
        int marks;
        System.out.println("enter the number");
        Scanner sc=new Scanner(System.in);

        marks=sc.nextInt();

        if(marks<32)
        {
           System.out.println("pass") ;
        }
       else if(marks<40)
        {
            System.out.println("average");
        }
       else if(marks<60)
        {
          System.out.println("good");
        }
       else if(marks<80)
        {
            System.out.println("very good");
        }
       else if(marks<90)
        {
            System.out.println("excellent");
        }
       else
        {
            System.out.println("invalid number");
        }

    }
}

