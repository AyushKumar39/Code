import java.lang.*;
import java.util.Scanner;

class Quadratic_equation
{
    public static void main(String[] args)
    {
        float a, b, c;
        double r1, r2;

        System.out.println(" enter the value of a and b and c ");

        Scanner sc = new Scanner(System.in);
        a = sc.nextFloat();
        b = sc.nextFloat();
        c = sc.nextFloat();

        r1 = (-b + Math.sqrt(b * b - 4 * a * c)) / (2 * a);
        r2 = (-b - Math.sqrt(b * b - 4 * a * c)) / (2 * a);

        System.out.println("root value " + r1 + " " + r2);
    }


  /*  class Cuboid
    {
        public static void main(String[] args)
        {
            Scanner sc = new Scanner(System.in);
            int length, breadth, height;
            int area, volume;

            System.out.println("enter the value of length breadth and height ");
            length = sc.nextInt();
            breadth = sc.nextInt();
            height = sc.nextInt();

            area = 2 * (length * breadth + length * height + breadth * height);
            volume = length * breadth * height;


        }
    }*/
}

