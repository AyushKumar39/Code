import java.lang.*;
import java.util.*;

class keyboard
{
    public static void main(String arg[])
    {
        Scanner s=new Scanner(System.in);
        int a,b,c;
        System.out.println("enter 2 number");
        a=s.nextInt();
        b=s.nextInt();
        c=a+b;
        System.out.println("sum is " +c);
    }
}