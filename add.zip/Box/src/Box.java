import java.lang.*;
import java.util.*;
 class Box2{
     private double length;
    private double width;
    private double height;
    public Box2(double length,double width,double height){
        this.length=length;
        this.width=width;
        this.height=height;
    }
    public double area(){
        return 2*(length*width + length*height + height*width);
    }
    public double volume(){
        return length*width*height;
    }
}
class Box3{
    public static void main(String...ayush){
        Box b1=new Box(10,20,15);

        System.out.println(" area : "+b1.area());
        System.out.println(" volume : " +b1.volume());

    }
}
