import java.lang.*;
import java.util.*;

   class Circle{
    public double radius;
    public double area(){
        return Math.PI*radius*radius;
    }
    public double diameter(){
        return radius*2;
    }
    public double circumference(){
        return 2*Math.PI*radius;
    }
}
 class Circle1{
    public static void main(String []args) {
       Circle c=new Circle();
        //Circle c2=new Circle();
        //c2.radius=9;
        //System.out.println("radius 2 :"+c2.radius);
        c.radius=6;
        System.out.println("radius 1 :"+c.radius);
         System.out.println("area :"+c.area());
        System.out.println("diameter :"+c.diameter());
        System.out.println("circumference :"+c.circumference());

 }
         }