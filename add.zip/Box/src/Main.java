import java.lang.*;
import java.util.*;

class Box {
    private double length;
    private double width;
     private double height; //package accesses (not to take any decision its a decision)
    public Box(double length, double width, double height) {
        this.length = length; //current object=this.____
        this.width = width;  //current object  = this.__
        this.height = height; //current object  = this.__
    }
    public double area() {
        return 2 * (length * width + length * height + width * height);
    }
    public double volume() {
        return length * width * height;
    }
    public void setHeight(double h) {
        height =h;
    }
    public double getHeight() {
        return  height;
    }
    public String  toString() {
        return "box :"+height +" "+width +" " +length;
    }
}
     class Box1{
        public static void main(String []args) {
           Box b1=new Box(10,20,15);
           //b1.length=10;
           //b1.width=20;
           b1.setHeight(15);
            System.out.println ( " " +b1);
            System.out.println(b1.getHeight());
            System.out.println("area " +b1.area());
            System.out.println("area "+b1.volume());
        }
    }

