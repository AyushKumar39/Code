package Parking;

public interface Vehicle {

}
