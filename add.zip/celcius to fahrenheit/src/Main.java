import java.lang.*;
import java.util.Scanner;

class Celcius_to_fahrenheit
{
    public static void main(String []args)
    {
        double celsius,fahrenheit;
        System.out.println("enter the value");
        Scanner sc=new Scanner(System.in);

        celsius=sc.nextInt();
        fahrenheit=(9/5.0)*celsius+32;
        System.out.println("fahrenheit is " +fahrenheit);

    }
}
