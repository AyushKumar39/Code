public class Car {
    private int NumberOfWheel = 4;
    private int SittingCapacity;
    private double GroundClearance;

    public Car(int SittingCapacity, double GroundClearance) {
        this.SittingCapacity = SittingCapacity;
        this.GroundClearance = GroundClearance;
    }

    public int getNumberOfWheels() {
        return NumberOfWheel;
    }

    public int getSittingCapacity() {
        return SittingCapacity;
    }

    public double getGroundClearance() {
        return GroundClearance;
    }
}
    class SUVCar extends Car {
        SUVCar(int SittingCapacity, double GroundClearance) {
            super(SittingCapacity, GroundClearance);
        }
    }

    class Luxury extends Car {
        Luxury(int SittingCapacity, double GroundClearance) {
            super(SittingCapacity, GroundClearance);
        }
    }

    class RaceCar extends Car {
        RaceCar(int SittingCapacity, double GroundClearance) {
            super(SittingCapacity,GroundClearance);
        }
    }
    class Car1{
    public static void main(String []args){
        SUVCar sc=new SUVCar(6,2.9);
        sc.getNumberOfWheels();
        sc.getSittingCapacity();
        sc.getGroundClearance();
        Luxury l=new Luxury(4,1.2);
        l.getNumberOfWheels();
        l.getSittingCapacity();
        l.getGroundClearance();
        RaceCar rc=new RaceCar(2,1.2);
        rc.getNumberOfWheels();
        rc.getSittingCapacity();
        rc.getGroundClearance();
    }
    }
