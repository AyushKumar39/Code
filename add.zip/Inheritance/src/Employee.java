import java.util.*;
public class Employee {
    private String name;
    private int employeeID;
    private double basicSalary;
    public Employee(String name,double basicSalary) {
         this.name=name;
         this.basicSalary=basicSalary;
    }
    public double getBasicSalary(){
        return basicSalary;
    }
    public double hra(){
        return 0;
    }
    public double da(){
        return 0;
    }
    public double ta(){
        return 0;
    }
    public double gross(){
       return basicSalary+hra()+da()+ta();
    }
    public double pf(){
        return 0;
    }
    public double net(){
       return gross()-pf();
    }
}
    class SupportStaff extends Employee{
        public SupportStaff( String name) {
            super(name,10000);
        }
        public double hra(){
           double d= getBasicSalary();
            return d=d*0.10;
        }
        public double da(){
            double d=getBasicSalary();
            return d=d*0.25;
        }
        public double ta(){
            double d=getBasicSalary();
            return d=d*0.10;
        }
        public double pf(){
            double d=getBasicSalary();
            return d=d*0.15;
        }

    }
    class Manager extends Employee{
       Manager(String Name){
           super(Name,50000);
       }
        public double hra(){
            double d= getBasicSalary();
            return d=d*0.20;
        }
        public double da(){
            double d=getBasicSalary();
            return d=d*0.35;
        }
        public double ta(){
            double d=getBasicSalary();
            return d=d*0.15;
        }
        public double pf(){
            double d=getBasicSalary();
            return d=d*0.25;
        }
}
  class Programmer extends Employee{
        Programmer(String Name){
            super(Name,30000);
         }
      public double hra(){
          double d= getBasicSalary();
          return d=d*0.15;
      }
      public double da(){
          double d=getBasicSalary();
          return d=d*0.32;
      }
      public double ta(){
          double d=getBasicSalary();
          return d=d*0.10;
      }
      public double pf(){
          double d=getBasicSalary();
          return d=d*0.20;
      }

        }
    class Employee1 {
        public static void main(String[] args) {
          Employee[] emp=new Employee[5];
            Scanner sc=new Scanner(System.in);
            for(int i=0;i<emp.length;i++){
                System.out.println("enter degination : Manager supportStaff Programmer");
                String deg=sc.nextLine();
                System.out.println(" enter name ");
                String name=sc.nextLine();
                if(deg.equals("Manager")){
                    emp[i]=new Manager(name);
                } else if (deg.equals("Programmer")) {
                    emp[i]=new Programmer(name);
                }else{
                    emp[i]=new SupportStaff(name);
                }
            }
            for(Employee e:emp){
                System.out.println(e.getBasicSalary() +" " +e.net() +" " +e.gross() +" " +e.hra());
            }
        }
    }