 /*import java.util.*;
 class Employee{
        int salary=2000;


}
class Lawyer extends Employee{
     public void DoLegalWork(){
         System.out.println(" legal work");
     }
}
 class Marketer extends Employee {
     public void DoMarketingWork() {
         System.out.println(" Marketing Work");
     }
 }
class Secretary extends Employee{
     public void DoManagementWork(){
         System.out.println(" Management Work ");
     }
}
class LegalSecretary extends Secretary{
     public void DoTypingWork(){
         System.out.println("Typing Work");
     }
 }
 class Main{
     public static void main(String[] args){
         Employee e=new Employee();
         //e.getSalary();

         Marketer m=new Marketer();
         m.DoMarketingWork();
        // m.getSalary();

         Lawyer l=new Lawyer();
         l.DoLegalWork();
         //l.getSalary();

         LegalSecretary ls=new LegalSecretary();
         ls.DoTypingWork();
         ls.DoManagementWork();
         //ls.getSalary();
     }
 }*/