public class ayush
        {
            public static void ayush (string[] args)
                system.out.println("hellow world");
        }