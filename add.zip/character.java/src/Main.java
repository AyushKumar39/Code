import java.lang.*;
import java.util.*;
 class Keyboard
 {
     public static void main(String arg[])
     {
         Scanner s=new Scanner(System.in);
         String name;
         System.out.println("may i know your name");
         name=s.nextLine();
         System.out.println("welcome Mr\\Mrs "+name);
     }
 }