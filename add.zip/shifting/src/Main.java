import java.lang.*;
import java.util.Scanner;


        //LEFT SHIFT

/* class Shifting
 {
    public static void main(String[] args)
    {
        int a,c;
        System.out.println("enter the value");
        Scanner sc = new Scanner(System.in);

        a = sc.nextInt();
       // b = sc.nextInt();
        c = a<<2;
        System.out.println("left shift program " + c);
    }

}
    //RIGHT SHIFT


   class Right_shift
   {
        public static void main(String[] args)
         {

            int x,z;
            System.out.println("enter the number ");
            Scanner sc = new Scanner(System.in);

            x = sc.nextInt();
           // y = sc.nextInt();
            z = x >>2;
            System.out.println("right shift program " + z);
        }
    }*/


    class Unsigned_shift
    {
        public static void main(String []args)
        {
            int a,b;
            System.out.println( "enter the value ");
            Scanner sc=new Scanner(System.in);

            a=sc.nextInt();
            b=a>>>2;
            System.out.println("unsigned value " +b);

        }
    }

