 import java.lang.*;
import java.util.Scanner;
import java.lang.String;

class Life_stage
{
    public static void main(String[] args)
    {
        int age;
        String life;
        System.out.println("enter the age");
        Scanner sc = new Scanner(System.in);

        age=sc.nextInt();

        life = (age>=0 && age < 1) ? "infant" : (age > 1 && age < 5) ? "baby" : (age >= 5 && age < 13) ? "child" : (age >= 13 && age < 18) ? "teenager" : (age >= 18 && age < 60) ? "adult" : "senior citizen";

        System.out.println("life = " + life);

    }
}