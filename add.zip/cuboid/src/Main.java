import java.lang.*;
import java.util.Scanner;

class Cuboid
 {
     public static void main(String []args)
     {
         Scanner sc=new Scanner(System.in);
         int length,breadth,height;
         int  area,volume;

                System.out.println(" enter length breadth and height ");
                  length=  sc.nextInt();
                   breadth=  sc.nextInt();
                    height= sc.nextInt();

                area = 2*(length*breadth+length*height+breadth*height);
                volume=length*breadth*height;

                System.out.println("total area "+area);
                System.out.println("total volume "+volume);
     }
 }