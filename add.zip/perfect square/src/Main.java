import java.lang.*;
import java.util.Scanner;


class Guessing_number
{
    public static void main(String []args)
    {
        Scanner sc = new Scanner(System.in);
        int number = 1 + (int) (10 * Math.random());


       // System.out.println("number " + number);


       int k = 3;
        int i, guess;

        System.out.println("number is chosen  1 to 9 " + "\n guess the number ");
        for (i = 0; i < k; i++)
        {
            System.out.println("Guess the number ");
            guess = sc.nextInt();

            if (number == guess)
            {
                System.out.println("congratulation you find the number ");
                break;
            }
            else if (number < guess)
            {
                System.out.println("your number is greater value ");
            }
            else if (number > guess)
            {
                System.out.println("your number is lesser value ");
            }
            else
            {
                System.out.println("invalid number");
            }
        }
    }
}
