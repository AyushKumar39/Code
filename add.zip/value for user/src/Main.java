import java.lang.*;
import java.util.*;

class User_input
{
    public static void main(String []ayush)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the size of array ");
       int  a=sc.nextInt();
       int  x[]=new int [a];
       for(int v:x)
       {
         System.out.println("enter the value : ") ;
         x[v]=sc.nextInt();

         if(x[v]%7==0)
         {
             System.out.println("yes");
         }
         else
         {
             System.out.println("no");
         }
       }
    }
}

