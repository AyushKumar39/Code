package pattern;

import java.util.Scanner;

public class HalfButterfly {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter tha numbers : ");
        int x = sc.nextInt();
        for (int i =1; i <=2*x; i++) {
            int totalcolumn;
            if(i>x){
                totalcolumn = 2*x-i;
            }else{
                totalcolumn=i;
            }
            for (int j =1; j <= totalcolumn; j++) {
                System.out.print("* ");
             }
            System.out.println();

        }
    }
}
