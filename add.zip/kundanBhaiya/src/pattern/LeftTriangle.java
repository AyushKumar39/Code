package pattern;

import java.util.Scanner;

public class LeftTriangle {
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the Number : ");
        int x=sc.nextInt();
        for(int i=1;i<=x;i--){
            for(int j=i-1;j>=0;j--){
                System.out.print(" *");
            }
            System.out.println();
        }
    }
}
