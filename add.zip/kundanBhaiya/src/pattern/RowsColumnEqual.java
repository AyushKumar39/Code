package pattern;

import java.util.Scanner;

public class RowsColumnEqual {
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the number : ");
        int x=sc.nextInt();
        for(int row=1;row<=x;row++){
            for(int col=1;col<=x;col++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
