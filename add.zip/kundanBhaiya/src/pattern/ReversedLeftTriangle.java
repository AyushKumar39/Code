package pattern;

import java.util.Scanner;

public class ReversedLeftTriangle {
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the Number : ");
        int x=sc.nextInt();
        for(int row=1;row<=x;row++){
            for(int col=1;col<=x-row+1;col++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
