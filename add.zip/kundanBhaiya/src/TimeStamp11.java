import java.util.Date;
import java.sql.Timestamp;
public class TimeStamp11 {
    public static void main(String []args){
        Date date1=new Date();
        Timestamp ts=new Timestamp(date1.getTime());
        System.out.println(ts);
            }
}
