package Number;

import java.sql.SQLOutput;

public class nameOnSepatareLine {

    public static void main(String []agrs){
        System.out.println("Hello");
        System.out.print("Ayush kumar");
    }
}
