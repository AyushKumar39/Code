package Number;

import java.util.Scanner;

public class AlternatePrime {


}
