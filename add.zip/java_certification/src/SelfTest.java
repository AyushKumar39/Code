public class SelfTest {
    private void blastOff() {
        System.out.println("bang ");


    }
}

