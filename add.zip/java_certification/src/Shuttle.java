public class Shuttle extends SelfTest {
    public static void main(String[] args) {
        new Shuttle().go();

    }

    void go() {
        blastOff();
        //rocket.blastOff();
    }

    private void blastOff() {
        System.out.println("sh-bang");
    }
}
