public class LoopSyntax {
    static public void main(String [] __A_V_){
        String $ ="";
        for(int x=0; ++x <__A_V_.length;)
            $+=__A_V_[x];
        System.out.println($);
    }
}
