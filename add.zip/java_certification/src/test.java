 class test {
     //    public  final void ayush()     //can't  overridden final method
//     {
//        System.out.println("one things");
//     }
//     class subtest extends test{
//        public void ayush1(){
//            System.out.println("another things");
//        }
//     }
//
//                // ABSTRACT CLASS
//
//     abstract public class Illegalcalss{
//        public abstract void doIt();   // class must be abstract even method is abstract
//    }
//     public abstract class vehicle{
//        private String type;
//        public abstract void goUPHill();     //abstract method
//        public String getType(){            // non abstract method
//            return type;
//        }
//    }
//    public  abstract class car extends vehicle{
//        public abstract void goUpHill();          //still abstract it can overridden
//        public void  doCarThings(){
//
//        }
//     }
//     public class Mini extends car{
//         public  void goUpHill() {
//
//         }
//
//         @Override
//         public void goUPHill() {
//
//         }
//     }
     static class aa {
         int size = 27;

         public void setSize(int size) {
             size=size;

         }

//         public void count() {
//             System.out.println("instance variable " + count);
//         }
    }

     public static void main(String[] args) {
         //new aa().loginId();
         new aa().setSize(27);
     }
 }

