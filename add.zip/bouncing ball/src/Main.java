import java.lang.*;
import java.util.Scanner;

class Bouncing_ball
{
    public static void main(String []args)
    {
        double ball,bounce;
        System.out.println("enter the ball length");
        Scanner sc=new Scanner(System.in);

        ball=sc.nextDouble();
        bounce=sc.nextDouble();

     do
     {
          ball=ball+(ball/2)*2;
         //bounce=
          System.out.println("bouncing ball " +ball);
        // System.out.println("bounce " +bounce);
     }
     while(ball<10);

    }
}
