import java.lang.*;
import java.util.*;
class Max_Min{
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the value");
        int x=sc.nextInt();
        int z[]=new int [x];
        for(int i=0;i<x;i++){
            z[i]=sc.nextInt();
            System.out.println("your input is : "+z[i]);
        }
        int Max=Integer.MIN_VALUE;
        int Min=Integer.MAX_VALUE;
        for(int i=0;i<z.length;i++){
          if(z[i]<Min){
              Min=z[i];
            }
          if(z[i]>Max){
              Max=z[i];
            }
        }
        System.out.println("largest number is : "+Max);
        System.out.println("Smallest number is : "+Min);

    }
}