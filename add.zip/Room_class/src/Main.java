import java.lang.*;
import java.util.*;
 class Room {
    int height, length, width;

    public Room(int length, int width, int height) {
        this.length = length;
        this.width = width;
        this.height = height;
    }

    public int area() {
        int area = 2 * ((length * width) + (width * height) + (length * height));
        return area;
    }

    public int volume() {
        return length*width*height;
    }

    public double  acSize(){

        if (volume() < 1000) {
            //System.out.println("acSize: "+1);
            return 1;
        } else if (volume() < 1500) {
            // System.out.println("acSize: "+1.5);
            return 1.5;
        } else if (volume() < 2000) {
            //System.out.println("acSize: "+2);
            return 2;
        } else if (volume() < 2500) {
            //System.out.println("acSize: "+2.5);
            return 2.5;
        } else if (volume() < 3000) {
            // System.out.println("acSize: "+3);
            return 3;
        } else if (volume() < 3500) {
            // System.out.println("acSize: "+3.5);
            return 3.5;
        } else if (volume() < 4000) {
            // System.out.println("acSize: "+4);
            return 4;
        } else if (volume() < 4500) {
            // System.out.println("acSize: "+4.5);
            return 4.5;
        } else {
            //System.out.println("acSize: not valid");
            return 0;
        }
        }
    public String toString(){
        return "Room :" +length +" " +width +" " +height;
    }
}
class Room1{
    public static void main(String []args){
        //Scanner sc=new Scanner(System.in);
        Room r1=new Room(10,20,30);
        System.out.println(" "+r1);
        System.out.println("area: "+r1.area());
        System.out.println("volume "+r1.volume());
        System.out.println(" "+r1.acSize());
    }
}

