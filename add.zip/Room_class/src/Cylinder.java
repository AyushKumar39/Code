/*import java.util.*;
public class Cylinder {
        public double radius;
        public double height;
        public double area(){
            return Math.PI*radius*radius;
        }
        public double totalSurfaceArea(){
            return 2*area()+circumference()*height;
        }
        public double circumference(){
            return 2*Math.PI*radius;
        }
        public double volume(){
            return area()*height;
        }
    }
    class Cylinder1{
        public static void main(String []args){
            Cylinder1 c=new Cylinder1();

            System.out.println("area :" +c.area());
            System.out.println("area :" +c.totalSurfaceArea());
            System.out.println("area :" +c.volume());
        }
    }*/

