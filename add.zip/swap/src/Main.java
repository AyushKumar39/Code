import javax.xml.crypto.Data;
import java.lang.*;
import java.util.*;

class Swap{
    public static void main(String []args){
        int i=10;
        int j=20;
        System.out.println(i);
        System.out.println(j);
      Data d1=new Data(); d1.a=10;
      Data d2=new Data(); d2.b=20;

      swapv2(d1,d2);
      System.out.println(d1.a);
      System.out.println(d2.a);
    }
    static void swap(Data x,Data y){
        Data z=new Data();
        z.a=x.a;
        x.a=y.a;
        y.a=z.a;
    }
    static void swapv2(Data x,Data y){
        Data z=x;
        x=y;
        y=z;
    }
    static void swapv2(int x,int y){
        int z=x;
        x=y;
        y=z;
    }
    class Data{
        int a;
        int b;
    }
}