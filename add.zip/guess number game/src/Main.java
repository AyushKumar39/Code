 import java.lang.*;
import java.util.Scanner;

/* first  the program should generate a random number ranging  from 0 to 9  */
class Guessing_game
{
    public static void main(String []args) {



        Scanner sc = new Scanner(System.in);
        int myNumber=(int)(Math.random()*10);
        int a=0;

        while(a>10)
        a=sc.nextInt();

        if (a==myNumber)
        {
            System.out.println("congratulation " +a);

        }
        else if (a>myNumber)
        {
          System.out.println("greater value " +a);

        }
        else
        {
            System.out.print("lesser value " +a);
        }
    }
}