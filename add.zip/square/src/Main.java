 import java.lang.*;
import java.util.Scanner;

class Perfect_square
{
       // double sqrt =Math.sqrt(number);
        //return ((sqrt-Math.floor(sqrt))==0);
        public static void main(String[] args)
        {

           System.out.println("enter the number");

           Scanner sc=new Scanner(System.in);
           d1=sc.nextDouble();
           //d2=sc.nextDouble();
           //square=Math.sqrt(d1);
           //power=Math.pow(d1,0.5);

                   //System.out.println("square = "+square);
                   //System.out.println("power = " +power);

        }
}
