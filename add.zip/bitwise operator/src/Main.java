import java.lang.*;
import java.util.Scanner;

 class Bitwise_operator
 {

               //NEGATION_VALUE
     public static void main(String []args)
     {
         //int a=0,b=2,c,d;
         //int x=~~3,y=~~4;
         //System.out.println("enter the negation value");
         //Scanner sc=new Scanner(System.in);

         //a=sc.nextInt();
        // b= sc.nextInt();

//         d=~a;
//         c=~b;
//         System.out.println("negation value " +d +" " +c);
        // System.out.println("negation value " +x +" " +y);


     }

 }


