 import java.lang.*;
 import java.util.Scanner;
 import java.util.Scanner.*;

class Herons_formula
{
    public static void main(String []args)
    {
        float a,b,c,s;
        double area;
        System.out.println(" enter 3 sides of a triangle ");

        Scanner sc=new Scanner(System.in);
                a=sc.nextFloat();
                b=sc.nextFloat();
                c=sc.nextFloat();
                s=(a+b+c)/2;

                area=Math.sqrt(s*(s-a)*(s-b)*(s-c));

                System.out.println("(area of a triangle " +area);

    }
}

