/*package Ayush;
import java.util.*;
 class Final{
public static void main(String []args){
    Foo f=new Foo();
    System.out.println(f);
    f.WhoIAM();
}
 }
 class Foo{
     void WhoIAM(){
         System.out.println("I Am "+this);
     }
 }*/