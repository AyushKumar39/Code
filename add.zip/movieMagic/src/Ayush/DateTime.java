package Ayush;
import java.lang.*;
import java.util.*;
public class DateTime {
    private int Year;
    private int month;
    private int day;
    private int hours;
    private int minutes;
    private int second;
    public  DateTime(int Year,int month,int day,int hours,int minutes,int second){
        this.Year=Year;
        this.month=month;
        this.day=day;
        this.hours=hours;
        this.minutes=minutes;
        this.second=second;
    }
    public int getYear(){
        return Year;
    }
    public int getMonth(){
        return month;
    }
    public int getDay(){
        return day;
    }
    public int getHours(){
        return hours;
    }
    public int getMinutes(){
        return minutes;
    }
    public int getSecond(){
        return second;
    }
    int  addYear(int yr){
         Year=Year+yr;
         return yr;
    }
    int addMonth(int mon){
     month=month+mon;
     int yr=month/12;
     addYear(yr);
     month=month%12;
     return month;
    }
    int  addDay(int da){
        day=day+da;
        int mon=day/30;
        addMonth(mon);
        day=day%30;
        return day;
    }
    int addHours(int hr){
        hours=hours+hr;
        int da=hours/24;
        addDay(da);
        hours=hours%24;
        return hours;
    }
    int addMinutes( int min){
        minutes=minutes+min;
        int hr=minutes/60;
        addHours(hr);
        minutes=minutes%60;
        return minutes;
    }
    int addSecond(int sec){
        second=second+sec;
        int min=second/60;
        addMinutes(min);
        second=second%60;
        return second;
    }

    public String toString(){
        return "DateTime : " +":" + Year + ":" + month + ":" + day + ":" + hours + ":" + minutes + ":" + second;}
}
class DateTime1{
     public static void main(String []args){
        Scanner sc=new Scanner(System.in);
         System.out.println("year");
         int Year=sc.nextInt();
         System.out.println("month");
         int month=sc.nextInt();
         System.out.println("day");
         int day= sc.nextInt();
         System.out.println("hours");
         int hours=sc.nextInt();
         System.out.println("minutes");
         int minutes=sc.nextInt();
         System.out.println("second");
         int second=sc.nextInt();


         DateTime  dt1=new DateTime(Year,month,day,hours,minutes,second);
         System.out.println(dt1);
         dt1.addYear(2);
         dt1.addMonth(3);
         dt1.addDay(3);
         dt1.addHours(2);
         dt1.addMinutes(5);
         dt1.addSecond(9);
         System.out.println("YEAR  : "+dt1.getYear());
         System.out.println("MONTH : "+dt1.getMonth());
         System.out.println("DAY   : "+dt1.getDay());
         System.out.println("HOURS : "+dt1.getHours());
         System.out.println("MIN   : "+dt1.getMinutes());
         System.out.println("SEC   : "+dt1.getSecond());
     }
}
