import java.util.*;
 class MovieMagic {
    public int year;
    public String title;
    public float rating=0.0f;
    public MovieMagic(int year,String title,float rating){
        this.year=year;
        this.title=title;
        this.rating=rating;
    }

    public String ratingMessage(){
        if(rating <=2.0f){
            return "flop";
        }else if(2.0<rating && rating<=3.4f){
            return "semi-hit";
        }else if(3.4<rating&& rating<=4.5f){
            return "hit";
        }else{
            return "super hit";
        }
    }
    public String toString(){
        return  "MovieMagic :" +title +" " +year +" " +rating;
    }
}
class MovieMagic1{
    public static void main(String []args){
        Scanner sc=new Scanner (System.in);
        System.out.println(sc);
        int year=sc.nextInt();
        String movie=sc.nextLine()+sc.nextLine();
        float rating=sc.nextFloat();
        MovieMagic m1=new MovieMagic(year,movie ,rating);
        System.out.println( m1);
        System.out.println(m1.ratingMessage());
    }
}

