import java.lang.*;
import java.util.*;
class Ascending_order{
    public static void main(String []ayush){
        Scanner sc=new Scanner(System.in);
        int x=sc.nextInt();
        int z[]=new int[x];
        for(int i=0;i<x;i++){
            z[i]= sc.nextInt();
            System.out.println("enter the value : " +z[i]);
        }
        boolean is_ascending=true;
        for(int i=0;i<z.length-1;i++){
         if(z[i]>z[i+1]){
             is_ascending=false;
         }
        }
        if(is_ascending){
            System.out.println("ascending order");
        }
        else{
            System.out.println("not ascending order");
        }
    }
}
