 import java.lang.*;
import java.util.*;
class Dress{
    private String materialUsed;
    private int size;
    private String color;
    private char gender;
    public Dress(String materialUsed,int size,String color,char gender){
       this.materialUsed=materialUsed;
       this.size=size;
       this.color=color;
       this.gender=gender;
    }
    public String getMaterialUsed(){return materialUsed;}
    public int getSize(){return size;}
    public String getColor(){return color;}
    public  char getGender(){return gender;}
    public String suitableWeather(){
        String weather=" ";
        if(materialUsed.equals("woolean")){
            weather="winter";
        }else if (materialUsed.equals("cotton")){
            weather="summer";
        }
        else if(materialUsed.equals("rainy Dress")){
            weather="rain";
        }
        return weather;
    }
}
class Dress1{
    public static void main(String []args){
        Dress d1=new Dress("fabric",32,"black", 'M');
        String S=d1.suitableWeather();
        System.out.println("Used material dress :"+d1.getMaterialUsed());
        System.out.println("size of  dress :"+d1.getSize());
        System.out.println("color of dress :"+d1.getColor());
        System.out.println("only used for :"+d1.getGender());
        System.out.println("this is suitable for :"+S);

    }
         }